"""
  Utility program for definining neural networks
"""

import tensorflow._api.v2.compat.v1 as tf
tf.disable_v2_behavior()
import numpy as np

def full_connect_var(dim_i, dim_o):
    tw = tf.Variable(tf.truncated_normal([dim_i, dim_o], stddev=0.1))
    tb = tf.Variable(tf.constant(0.0, shape=[dim_o]))
    return (tw, tb)
def full_connect(tinput, twb, activate = tf.nn.relu):
    (tw, tb) = twb
    return activate(tf.matmul(tinput, tw) + tb)
def full_connect_raw(tinput, twb):
    (tw, tb) = twb
    return tf.matmul(tinput, tw) + tb


def auto_encoder_var(dim_i,dim_h,dim_o):
    tw1 = tf.Variable(tf.truncated_normal([dim_i, dim_h], stddev=0.1))
    tb1 = tf.Variable(tf.constant(0.0, shape=[dim_h]))
    tw2 = tf.Variable(tf.truncated_normal([dim_h, dim_o], stddev=0.1))
    tb2 = tf.Variable(tf.constant(0.0, shape=[dim_o]))
    return (tw1,tb1,tw2,tb2)
def auto_encoder(tinput, twb, activate1 = tf.nn.relu, activate2 = tf.nn.sigmoid):
    (tw1, tb1, tw2, tb2) = twb
    hiden_state = activate1(tf.matmul( tinput, tw1 ) + tb1)
    return activate2 ( tf.matmul(hiden_state, tw2) + tb2 )




def cnn_var(fx, fy, ich, och):
    tw = tf.Variable(tf.truncated_normal([fx, fy, ich, och], stddev=0.1))
    tb  = tf.Variable(tf.truncated_normal([och], stddev=0.1))
    return (tw, tb)
def cnn(tinput, twb,  activate = tf.nn.relu):
    (tw, tb) = twb
    return activate(tf.nn.conv2d(tinput, tw, strides=[1,1,1,1], padding='VALID') + tb)


def dual_cnn_var(fx, fy, ich, och):
    tw  = tf.Variable(tf.truncated_normal([fx, fy, ich, och], stddev=0.1))
    tb  = tf.Variable(tf.truncated_normal([och], stddev=0.1))
    return ((tw, tb), (tf.transpose(tw, perm=[1,0,2,3]), tb))
def dual_cnn(tinput, twba, twbb, activate = tf.nn.relu):
    (twa, tba) = twba
    (twb, tbb) = twbb
    return (activate(tf.nn.conv2d(tinput, twa, strides=[1,1,1,1], padding='VALID') + tba),
            activate(tf.nn.conv2d(tinput, twb, strides=[1,1,1,1], padding='VALID') + tbb))
