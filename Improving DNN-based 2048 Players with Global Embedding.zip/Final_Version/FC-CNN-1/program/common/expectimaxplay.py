# import tensorflow as tf
import tensorflow._api.v2.compat.v1 as tf
tf.disable_v2_behavior()
import numpy as np
import logging
import threading, concurrent.futures
import queue
import sys, os
import random

sys.path.append('../common')
import Game2048

# usage: python greedyplay.py 100 cnn22B ??/weights-40
# usage: python expecimaxplay.py 100 cnn22B ../weight/weights-100 3 100


seed = int(sys.argv[1])
modelname = sys.argv[2]
checkpointprefix = sys.argv[3]
expectimaxdepth = int(sys.argv[4])
NUM_GAMES = int(sys.argv[5])

num_thread = 2

base = modelname
exec(f'import {base} as modeler')
model = modeler.Model()

logfile = f'{checkpointprefix}-expectimax{expectimaxdepth}-s{seed}.log'

#乱数
random.seed(seed)
np.random.seed(seed)
tf.set_random_seed(seed)
np.set_printoptions(threshold=np.inf)

# if not os.path.exists(logdir): os.makedirs(logdir)

# ログ関連
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
fh = logging.FileHandler(logfile)
fh.setLevel(logging.DEBUG)
fh.setFormatter(logging.Formatter('%(name)s:%(levelname)s:%(asctime)s:%(message)s'))
logger.addHandler(fh)

# セッション用意
sess = tf.InteractiveSession()
sess.run(tf.global_variables_initializer())
saver = tf.train.Saver(max_to_keep=None)
saver.restore(sess, checkpointprefix)
logger.info(f'model restored')

queueA = queue.Queue(NUM_GAMES)

def expectimaxPlay2a(state, depth, sess, model):
    def make_input(x, board):
        for j in range(16):
            b = board[j]
            x[24 * j + b] = 1
            x[24 * j + 16 + int(j // 4)] = 1
            x[24 * j + 20 + j % 4] = 1
    def genBoards(state, depth):
        retBoards = np.zeros([4 * (128 ** (depth-1)), 384], dtype='int64')
        retRewards = np.zeros([4 * (128 ** (depth-1))], dtype='int64')
        def genBoardsRec(state, depth, reward, stindex):
            if depth == 1:
                retKey = stindex
                for d in range(4):
                    if [state.testUp, state.testRight, state.testDown, state.testLeft][d]():
                        s = state.clone()
                        [s.doUp,s.doRight,s.doDown,s.doLeft][d]()
                        make_input(retBoards[stindex + d,:], s.board)
                        retRewards[stindex + d] = s.score - state.score + reward
                    else:
                        retRewards[stindex + d] = -1000000
                return retKey, stindex + 4
            else:
                retKey = []
                for d in range(4):
                    if not [state.testUp, state.testRight, state.testDown, state.testLeft][d]():
                        retKey.append((0, None))
                        continue
                    subkey = []
                    s = state.clone()
                    [s.doUp,s.doRight,s.doDown,s.doLeft][d]()
                    count = 0
                    for i in range(16):
                        if s.board[i] != 0: continue
                        count += 1
                        s.board[i] = 1
                        key, stindex = genBoardsRec(s, depth-1, reward + s.score - state.score, stindex)
                        subkey.append(key)
                        s.board[i] = 2
                        key, stindex = genBoardsRec(s, depth-1, reward + s.score - state.score, stindex)
                        subkey.append(key)
                        s.board[i] = 0
                    retKey.append((count, subkey))
                return retKey, stindex
        retKeys, size = genBoardsRec(state, depth, 0, 0)
        return retKeys, retRewards[0:size], retBoards[0:size,:]
    def selectMove(keys, scores, depth):
        if depth == 1:
            maxi = -1; maxv = 0
            stindex = keys
            for i in range(4):
                if maxi == -1 or scores[stindex + i] > maxv:
                    maxi = i; maxv = scores[stindex + i]
            return maxi, maxv
        else:
            maxi = -1; maxv = 0
            for d in range(4):
                count, subkey = keys[d]
                score = 0
                if count == 0: continue
                for i in range(count):
                    score += selectMove(subkey[2*i+0], scores, depth-1)[1] * 0.9 + selectMove(subkey[2*i+1], scores, depth-1)[1] * 0.1
                if maxi == -1 or score /count > maxv:
                    maxi = d; maxv = score / count
            return maxi, maxv

    keys, rewards, x = genBoards(state, depth)
    p = sess.run(model.output, feed_dict={model.input:x})
    for i in range(rewards.shape[0]): p[i,0] += rewards[i]
    dir, ev = selectMove(keys, p[:,0], depth)
    if dir == -1:
        if state.testUp(): return 0,0
        if state.testRight(): return 1,0
        if state.testDown(): return 2,0
        if state.testLeft(): return 3,0
    return dir, ev

def expectimaxPlay2(state, depth, sess, model):
    def genBoards(state, depth):
        retBoards = []
        retRewards = []
        def genBoardsRec(state, depth, reward, stindex):
            if depth == 1:
                retKey = [-1] * 4
                for d in range(4):
                    if [state.testUp, state.testRight, state.testDown, state.testLeft][d]():
                        s = state.clone()
                        [s.doUp,s.doRight,s.doDown,s.doLeft][d]()
                        retBoards.append(s.board)
                        retRewards.append(s.score - state.score + reward)
                        retKey[d] = stindex; stindex += 1
                return retKey, stindex
            else:
                retKey = []
                for d in range(4):
                    subkey = []
                    if not [state.testUp, state.testRight, state.testDown, state.testLeft][d]():
                        retKey.append((0, None))
                        continue
                    s = state.clone()
                    [s.doUp,s.doRight,s.doDown,s.doLeft][d]()
                    count = 0
                    for i in range(16):
                        if s.board[i] != 0: continue
                        count += 1
                        s.board[i] = 1
                        key, stindex = genBoardsRec(s, depth-1, reward + s.score - state.score, stindex)
                        s.board[i] = 0
                        subkey.append(key)
                    for i in range(16):
                        if s.board[i] != 0: continue
                        s.board[i] = 2
                        key, stindex = genBoardsRec(s, depth-1, reward + s.score - state.score, stindex)
                        s.board[i] = 0
                        subkey.append(key)
                    retKey.append((count, subkey))
                return retKey, stindex
        retKeys = genBoardsRec(state, depth, 0, 0)[0]
        return retKeys, retRewards, retBoards
    def selectMove(keys, scores, depth):
        if depth == 1:
            maxi = -1; maxv = 0
            for i in range(4):
                if keys[i] == -1: continue
                # print(f'checking depth = 1 with key={keys[i]}')
                if maxi == -1 or scores[keys[i]] > maxv:
                    maxi = i; maxv = scores[keys[i]]
            # print(f'returning depth = 1 with maxi = {maxi}, maxv = {maxv}')
            return maxi, maxv
        else:
            maxi = -1; maxv = 0
            for i in range(4):
                count, subkey = keys[i]
                if count == 0: continue
                score = (sum([selectMove(subkey[i], scores, depth-1)[1] for i in range(count)]) * 9
                         + sum([selectMove(subkey[i], scores, depth-1)[1] for i in range(count, count*2)])) / 10 / count
                if maxi == -1 or score > maxv:
                    maxi = i; maxv = score
            return maxi, maxv

    keys, rewards, boards = genBoards(state, depth)
    x = np.zeros([len(boards), model.DIM_I], dtype='float32')
    for i in range(len(boards)): model.make_input(x[i,:], boards[i])
    p = sess.run(model.output, feed_dict={model.input:x})
    # p = np.zeros([len(boards),1], dtype='int64')
    # for i in range(len(boards)): p[i,0] = random.randrange(100)
    for i in range(len(boards)): p[i,0] += rewards[i]
    dir, ev = selectMove(keys, p[:,0], depth)
    if dir == -1:
        if state.testUp(): return 0,0
        if state.testRight(): return 1,0
        if state.testDown(): return 2,0
        if state.testLeft(): return 3,0
    return dir, ev

def gameplay(gameID):
    def gameplayCore():
        with open(f'{checkpointprefix}-expectimax{expectimaxdepth}-s{seed}-g{gameID:03d}.log', 'w') as fp:
            # 1 ゲーム分プレイする
            state = Game2048.State()
            state.initGame()
            turn = 0
            while True:
                turn += 1
                dir,ev = expectimaxPlay2(state, expectimaxdepth, sess, model)
                state.print(fp)
                print(f'dir={dir}, ev={ev}', file=fp)
                fp.flush()
                state.play(dir)
                state.putNewTile()
                if state.isGameOver():
                    logger.info(f'game over {gameID} score {state.score} turn {turn} maxtile {max(state.board)}')
                    queueA.put({'id':gameID, 'score':state.score, 'turn':turn, 'maxtile':max(state.board)})
                    break
    return gameplayCore

with concurrent.futures.ThreadPoolExecutor(max_workers=num_thread) as player_executor:
    for  i in range(NUM_GAMES): player_executor.submit(gameplay(i))
# gameplay(0)()
# print('gameplayend')

results = []
for i in range(NUM_GAMES): results.append(queueA.get())

logger.info(f'After {NUM_GAMES} games')
logger.info(f'Average score: {np.mean([r["score"] for r in results])}')
logger.info(f'Max score: {max([r["score"] for r in results])}')
logger.info(f'Min score: {min([r["score"] for r in results])}')
logger.info(f'32768 clear count: {sum([1 if r["maxtile"] >= 15 else 0 for r in results])}')
logger.info(f'16384 clear count: {sum([1 if r["maxtile"] >= 14 else 0 for r in results])}')
logger.info(f' 8192 clear count: {sum([1 if r["maxtile"] >= 13 else 0 for r in results])}')
logger.info(f' 4096 clear count: {sum([1 if r["maxtile"] >= 12 else 0 for r in results])}')
logger.info(f' 2048 clear count: {sum([1 if r["maxtile"] >= 11 else 0 for r in results])}')




# def expectimaxPlay4(state, depth, sess, model):
#     if depth < 3: return expectimaxPlay6(state, depth, sess, model)
#     maxi, maxv = -1, 0
#     for d in range(4):
#         if not [state.testUp, state.testRight, state.testDown, state.testLeft][d](): continue
#         s = state.clone()
#         [s.doUp,s.doRight,s.doDown,s.doLeft][d]()
#         count, score = 0, 0
#         for i in range(16):
#             if s.board[i] == 0:
#                 count += 1
#                 s.board[i] = 1
#                 score += expectimaxPlay4(s, depth-1, sess, model)[1] * 0.9
#                 s.board[i] = 2
#                 score += expectimaxPlay4(s, depth-1, sess, model)[1] * 0.1
#                 s.board[i] = 0
#         if maxi == -1 or maxv < score / count:
#             maxi, maxv = d, score / count
#     return maxi, maxv
    
# def expectimaxPlay3(state, depth, sess, model):
#     maxi, maxv = -1, 0
#     if depth == 1:
#         x = np.zeros([4, model.DIM_I], dtype="float32")
#         rs = [0 for i in range(4)]
#         for d in range(4):
#             s = state.clone()
#             [s.doUp,s.doRight,s.doDown,s.doLeft][d]()
#             model.make_input(x[d,:], s.board)
#             rs[d] = s.score - state.score
#         p = sess.run(model.output, feed_dict={model.input:x})
#         for d in range(4):
#             if not [state.testUp, state.testRight, state.testDown, state.testLeft][d](): continue
#             if maxi == -1 or maxv < p[d,0]+rs[d]:
#                 maxi, maxv = d, p[d,0]+rs[d]
#     else:
#         for d in range(4):
#             if not [state.testUp, state.testRight, state.testDown, state.testLeft][d](): continue
#             s = state.clone()
#             [s.doUp,s.doRight,s.doDown,s.doLeft][d]()
#             count, score = 0, 0
#             for i in range(16):
#                 if s.board[i] == 0:
#                     count += 1
#                     s.board[i] = 1
#                     score += expectimaxPlay3(s, depth-1, sess, model)[1] * 0.9
#                     s.board[i] = 2
#                     score += expectimaxPlay3(s, depth-1, sess, model)[1] * 0.1
#                     s.board[i] = 0
#             if maxi == -1 or maxv < score / count:
#                 maxi, maxv = d, score / count
#     return maxi, maxv

# def expectimaxPlay2a(state, depth, sess, model):
#     def genBoards(state, depth):
#         retBoards = np.zeros([4 * (128 ** (expectimaxdepth-1)), model.DIM_I], dtype='int64')
#         retRewards = np.zeros([4 * (128 ** (expectimaxdepth-1))], dtype='int64')
#         def genBoardsRec(state, depth, reward, stindex):
#             if depth == 1:
#                 retKey = stindex
#                 for d in range(4):
#                     if [state.testUp, state.testRight, state.testDown, state.testLeft][d]():
#                         s = state.clone()
#                         [s.doUp,s.doRight,s.doDown,s.doLeft][d]()
#                         model.make_input(retBoards[stindex + d,:], s.board)
#                         retRewards[stindex + d] = s.score - state.score + reward
#                     else:
#                         retRewards[stindex + d] = -1000000
#                 return retKey, stindex + 4
#             else:
#                 retKey = []
#                 for d in range(4):
#                     if not [state.testUp, state.testRight, state.testDown, state.testLeft][d]():
#                         retKey.append((0, None))
#                         continue
#                     subkey = []
#                     s = state.clone()
#                     [s.doUp,s.doRight,s.doDown,s.doLeft][d]()
#                     count = 0
#                     for i in range(16):
#                         if s.board[i] != 0: continue
#                         count += 1
#                         s.board[i] = 1
#                         key, stindex = genBoardsRec(s, depth-1, reward + s.score - state.score, stindex)
#                         subkey.append(key)
#                         s.board[i] = 2
#                         key, stindex = genBoardsRec(s, depth-1, reward + s.score - state.score, stindex)
#                         subkey.append(key)
#                         s.board[i] = 0
#                     retKey.append((count, subkey))
#                 return retKey, stindex
#         retKeys, size = genBoardsRec(state, depth, 0, 0)
#         return retKeys, retRewards[0:size], retBoards[0:size,:]
#     def selectMove(keys, scores, depth):
#         if depth == 1:
#             maxi = -1; maxv = 0
#             stindex = keys
#             for i in range(4):
#                 if maxi == -1 or scores[stindex + i] > maxv:
#                     maxi = i; maxv = scores[stindex + i]
#             return maxi, maxv
#         else:
#             maxi = -1; maxv = 0
#             for d in range(4):
#                 count, subkey = keys[d]
#                 score = 0
#                 if count == 0: continue
#                 for i in range(count):
#                     score += selectMove(subkey[2*i+0], scores, depth-1)[1] * 0.9 + selectMove(subkey[2*i+1], scores, depth-1)[1] * 0.1
#                 if maxi == -1 or score /count > maxv:
#                     maxi = d; maxv = score / count
#             return maxi, maxv

#     keys, rewards, x = genBoards(state, depth)
#     p = sess.run(model.output, feed_dict={model.input:x})
#     for i in range(rewards.shape[0]): p[i,0] += rewards[i]
#     dir, ev = selectMove(keys, p[:,0], depth)
#     if dir == -1:
#         if state.testUp(): return 0,0
#         if state.testRight(): return 1,0
#         if state.testDown(): return 2,0
#         if state.testLeft(): return 3,0
#     return dir, ev

# def expectimaxPlay5(state, depth, sess, model):
#     def countBoards(state, depth):
#         if depth == 1: return 4
#         count = 0
#         for d in range(4):
#             if not [state.testUp, state.testRight, state.testDown, state.testLeft][d]():
#                 continue
#             s = state.clone(); [s.doUp,s.doRight,s.doDown,s.doLeft][d]()
#             for i in range(16):
#                 if s.board[i] != 0: continue
#                 s.board[i] = 1
#                 count += countBoards(s, depth-1)
#                 s.board[i] = 2
#                 count += countBoards(s, depth-1)
#                 s.board[i] = 0
#         return count
#     def genBoards(state, depth, boards, rewards, reward, stindex):
#         if depth == 1:
#             for d in range(4):
#                 if [state.testUp, state.testRight, state.testDown, state.testLeft][d]():
#                     s = state.clone()
#                     [s.doUp,s.doRight,s.doDown,s.doLeft][d]()
#                     model.make_input(boards[stindex + d,:], s.board)
#                     rewards[stindex + d] = s.score - state.score + reward
#                 else:
#                     rewards[stindex + d] = -1000000
#             return stindex + 4
#         for d in range(4):
#             if not [state.testUp, state.testRight, state.testDown, state.testLeft][d]():
#                 continue
#             s = state.clone(); [s.doUp,s.doRight,s.doDown,s.doLeft][d]()
#             for i in range(16):
#                 if s.board[i] != 0: continue
#                 s.board[i] = 1
#                 stindex = genBoards(s, depth-1, boards, rewards, reward + s.score - state.score, stindex)
#                 s.board[i] = 2
#                 stindex = genBoards(s, depth-1, boards, rewards, reward + s.score - state.score, stindex)
#                 s.board[i] = 0
#         return stindex
#     def selectMove(state, depth, scores, stindex):
#         maxi, maxv = -1, 0
#         if depth == 1:
#             for d in range(4):
#                 if maxi == -1 or maxv < scores[stindex + d]:
#                     maxi, maxv = d, scores[stindex + d]
#             return maxi, maxv, stindex + 4
#         for d in range(4):
#             if not [state.testUp, state.testRight, state.testDown, state.testLeft][d]():
#                 continue
#             s = state.clone(); [s.doUp,s.doRight,s.doDown,s.doLeft][d]()
#             count, score = 0, 0
#             for i in range(16):
#                 if s.board[i] != 0: continue
#                 count += 1
#                 s.board[i] = 1
#                 _, sc, stindex = selectMove(s, depth-1, scores, stindex); score += sc * .9
#                 s.board[i] = 2
#                 _, sc, stindex = selectMove(s, depth-1, scores, stindex); score += sc * .1
#                 s.board[i] = 0
#             if maxi == -1 or maxv < score / count:
#                 maxi, maxv = d, score / count
#         return maxi, maxv, stindex

#     count = countBoards(state, depth)
#     x = np.zeros([count, model.DIM_I], dtype='float32')
#     rs = np.zeros([count], dtype='float32')
#     genBoards(state, depth, x, rs, 0, 0)
#     p = sess.run(model.output, feed_dict={model.input:x})
#     for i in range(count):
#         rs[i] += p[i,0]
#     dir, ev, _ = selectMove(state, depth, rs, 0)
#     return dir, ev

# def expectimaxPlay6(state, depth, sess, model):
#     def genBoards(state, depth, boards, rewards, reward, stindex):
#         if depth == 1:
#             for d in range(4):
#                 if [state.testUp, state.testRight, state.testDown, state.testLeft][d]():
#                     s = state.clone()
#                     [s.doUp,s.doRight,s.doDown,s.doLeft][d]()
#                     model.make_input(boards[stindex + d,:], s.board)
#                     rewards[stindex + d] = s.score - state.score + reward
#                 else:
#                     rewards[stindex + d] = -1000000
#             return stindex
#         stepsize = (128 ** (depth-2)) * 4
#         retKey = []
#         for d in range(4):
#             if not [state.testUp, state.testRight, state.testDown, state.testLeft][d]():
#                 stindex += stepsize * 2 * 16
#                 retKey.append((0, None))
#                 continue
#             subKey = []
#             count = 0
#             s = state.clone(); [s.doUp,s.doRight,s.doDown,s.doLeft][d]()
#             for i in range(16):
#                 if s.board[i] != 0:
#                     stindex += stepsize * 2
#                     continue
#                 count += 1
#                 s.board[i] = 1
#                 subKey.append(genBoards(s, depth-1, boards, rewards, reward + s.score - state.score, stindex)); stindex += stepsize
#                 s.board[i] = 2
#                 subKey.append(genBoards(s, depth-1, boards, rewards, reward + s.score - state.score, stindex)); stindex += stepsize
#                 s.board[i] = 0
#             retKey.append((count, subKey))
#         return retKey
#     def selectMove(key, depth, scores):
#         maxi, maxv = -1, 0
#         if depth == 1:
#             stindex = key
#             for d in range(4):
#                 if maxi == -1 or maxv < scores[stindex + d]:
#                     maxi, maxv = d, scores[stindex + d]
#             return maxi, maxv
#         for d in range(4):
#             count, subKey = key[d]
#             if count == 0: continue
#             s = state.clone(); [s.doUp,s.doRight,s.doDown,s.doLeft][d]()
#             score = 0
#             for i in range(count):
#                 _, sc = selectMove(subKey[i*2+0], depth-1, scores); score += sc * .9
#                 _, sc = selectMove(subKey[i*2+1], depth-1, scores); score += sc * .1
#             if maxi == -1 or maxv < score / count:
#                 maxi, maxv = d, score / count
#         return maxi, maxv

#     x = np.zeros([4 * (128 ** (expectimaxdepth-1)), model.DIM_I], dtype='float32')
#     rs = np.zeros([4 * (128 ** (expectimaxdepth-1))], dtype='float32')
#     key = genBoards(state, depth, x, rs, 0, 0)
#     p = sess.run(model.output, feed_dict={model.input:x})
#     for i in range(4*(128 ** (expectimaxdepth-1))):
#         rs[i] += p[i,0]
#     dir, ev = selectMove(key, depth, rs)
#     return dir, ev

# def expectimaxPlay(state, depth, sess, model):
#     def genBoards(state, depth):
#         retKeys = []; retRewards = []; retBoards = []
#         funcs = ['Up', 'Right', 'Down', 'Left']
#         for d, func in enumerate(funcs):
#             if eval(f'state.test{func}()'):
#                 s = state.clone()
#                 eval(f's.do{func}()')
#                 if depth == 1:
#                     retKeys.append([d]); retRewards.append(s.score - state.score); retBoards.append(s.board)
#                 else:
#                     for i in range(16):
#                         if s.board[i] != 0: continue
#                         s2 = s.clone()
#                         s2.board[i] = 1
#                         keys, rewards, boards = genBoards(s2, depth-1)
#                         retKeys += [[d,i,1] + k for k in keys]; retRewards += [s.score - state.score + r for r in rewards]; retBoards += boards
#                         s4 = s.clone()
#                         s4.board[i] = 2
#                         keys, rewards, boards = genBoards(s4, depth-1)
#                         retKeys += [[d,i,2] + k for k in keys]; retRewards += [s.score - state.score + r for r in rewards]; retBoards += boards
#         return retKeys, retRewards, retBoards

#     def selectMove(keys, rewards, ps, depth):
#         # print(f'key = {keys}, rewards = {rewards}, ps = {ps}, depth = {depth}')

#         if depth == 1:
#             maxi = -1; maxv = 0
#             for i in range(len(keys)):
#                 # print(f'checking depth = 1 with key={keys[i]}')
#                 if maxi == -1 or rewards[i] + ps[i] > maxv:
#                     maxi = keys[i][0]; maxv = rewards[i] + ps[i]
#             # print(f'returning depth = 1 with maxi = {maxi}, maxv = {maxv}')
#             return maxi, maxv
#         else:
#             maxi = -1; maxv = 0
#             for d in range(4):
#                 scores = []
#                 for p in range(16):
#                     # print(f'checking depth = {depth} with d={d} p={p}')
#                     skeys2 = []; srewards2 = []; sps2 = []
#                     skeys4 = []; srewards4 = []; sps4 = []
#                     for i in range(len(keys)):
#                         if keys[i][0] == d and keys[i][1] == p and keys[i][2] == 1:
#                             skeys2.append(keys[i][3:]); srewards2.append(rewards[i]); sps2.append(ps[i])
#                     for i in range(len(keys)):
#                         if keys[i][0] == d and keys[i][1] == p and keys[i][2] == 2:
#                             skeys4.append(keys[i][3:]); srewards4.append(rewards[i]); sps4.append(ps[i])
#                     if len(skeys2) + len(skeys4) == 0: continue
#                     scores += [selectMove(skeys2, srewards2, sps2, depth-1)[1]] * 9
#                     scores += [selectMove(skeys4, srewards4, sps4, depth-1)[1]] * 1
#                 if len(scores) == 0: continue
#                 avescore = np.mean(scores)
#                 if maxi == -1 or avescore > maxv:
#                     maxi = d; maxv = avescore
#             # print(f'returning depth = {depth} with maxi = {maxi}, maxv = {maxv}')
#             return maxi, maxv

#     keys, rewards, boards = genBoards(state, depth)
#     # x = np.zeros([len(boards), model.DIM_I], dtype='int64')
#     # for i in range(len(boards)): model.make_input(x[i,:], boards[i])
#     p = np.zeros([len(boards),1], dtype='int64')
#     for i in range(len(boards)): p[i,0] = random.randrange(100)
#     # p = sess.run(model.output, feed_dict={model.input:x})
#     dir, ev = selectMove(keys, rewards, p[:,0], depth)
#     if dir == -1:
#         if state.testUp(): return 0,0
#         if state.testRight(): return 1,0
#         if state.testDown(): return 2,0
#         if state.testLeft(): return 3,0
#     return dir, ev
