
# import tensorflow as tf
import tensorflow._api.v2.compat.v1 as tf
tf.disable_v2_behavior()
import numpy as np
from nn_util import *



class Model:
    def __init__(self):
        '''
        Generation of Model
        '''
        self.DIM_I = 384
        self.DIM_O = 1
        chw1, chw2, chw3, chw4  = 256, 512, 1024, 256
        chwh = 32
        self.description = 'Auto encoder + two Conv2D (2x2) layers and three full-connect layers. Number of outputs of each layer is set 128, 256, 512, 1024, 256, 1.'
        self.numparams = (384 * 32 + 32) + (32 * 128 + 128) + (2 * 2 * 24 * chw1 + chw1) + (2 * 2 * chw1 * chw2 + chw2) + (chw2 * 4 * chw3 + chw3) + (chw3 * chw4 + chw4) + (chw4 * 1 + 1)

        # Placeholders for input and correct value
        self.input = tf.placeholder(tf.float32, [None, self.DIM_I])
        self.correct = tf.placeholder(tf.float32, [None, self.DIM_O])

        # Network structure

        sub_input = tf.reshape(self.input, [-1,4,4,24])
        sub_input1 = sub_input[:,:,:,0:16]
        sub_input2 = tf.reshape (sub_input , [-1, 384])
        output_global = auto_encoder( sub_input2, auto_encoder_var(384,32,128) )
        output_global2 = tf.reshape (output_global, [-1, 4, 4, 8])
        con_output = tf.concat ( [sub_input1,output_global2],3 )

        output1 = cnn(con_output, cnn_var(2, 2, 24, chw1))
        output2 = cnn(output1, cnn_var(2, 2, chw1, chw2))
        output2f = tf.reshape(output2, [-1, 2*2*chw2])
        output3f = full_connect(output2f, full_connect_var(chw2 * 4, chw3))
        output4f = full_connect(output3f, full_connect_var(chw3, chw4))
        self.output = full_connect_raw(output4f, full_connect_var(chw4, self.DIM_O))

        # Loss function and training algorithm
        self.loss = tf.reduce_mean(tf.math.squared_difference(self.output, self.correct))
        self.train_step = tf.train.AdamOptimizer().minimize(self.loss)

    def make_input(self, x, board):
        for j in range(16):
            b = board[j]
            x[24 * j + b] = 1
            x[24 * j + 16 + int(j//4) ] = 1
            x[24 * j + 20 + j%4 ] = 1