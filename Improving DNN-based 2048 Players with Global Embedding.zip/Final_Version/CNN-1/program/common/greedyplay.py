# import tensorflow as tf
import tensorflow._api.v2.compat.v1 as tf
tf.disable_v2_behavior()
import numpy as np
import logging
import threading, concurrent.futures
import queue
import sys, os
import random

sys.path.append('../common')
import Game2048

# usage: python greedyplay.py 100 cnn22B ??/weights-40
seed = int(sys.argv[1])
modelname = sys.argv[2]
checkpointprefix = sys.argv[3]
NUM_GAMES = int(sys.argv[4])

num_thread = 5

base = modelname
exec(f'import {base} as modeler')
model = modeler.Model()

logfile = f'{checkpointprefix}-greedy-s{seed}.log'

#乱数
random.seed(seed)
np.random.seed(seed)
tf.set_random_seed(seed)
np.set_printoptions(threshold=np.inf)

# if not os.path.exists(logdir): os.makedirs(logdir)

# ログ関連
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
fh = logging.FileHandler(logfile)
fh.setLevel(logging.DEBUG)
fh.setFormatter(logging.Formatter('%(name)s:%(levelname)s:%(asctime)s:%(message)s'))
logger.addHandler(fh)
logger.info('start')

# セッション用意
sess = tf.InteractiveSession()
sess.run(tf.global_variables_initializer())
saver = tf.train.Saver(max_to_keep=None)
saver.restore(sess, checkpointprefix)
logger.info(f'model restored')

queueA = queue.Queue(NUM_GAMES)

import playalg
# ゲームプレイスレッド
def gameplay(gameID):
    def gameplayCore():
        # 1 ゲーム分プレイする
        state = Game2048.State()
        state.initGame()
        turn = 0
        while True:
            turn += 1
            dir,ev = playalg.simplePlay(state, sess, model)
            state.play(dir)
            state.putNewTile()
            if state.isGameOver():
                logger.info(f'game over {gameID} score {state.score} turn {turn} maxtile {max(state.board)}')
                queueA.put({'id':gameID, 'score':state.score, 'turn':turn, 'maxtile':max(state.board)})
                break
    return gameplayCore

with concurrent.futures.ThreadPoolExecutor(max_workers=num_thread) as player_executor:
    for  i in range(NUM_GAMES): player_executor.submit(gameplay(i))
# gameplay(0)()

results = []
for i in range(NUM_GAMES): results.append(queueA.get())

logger.info(f'After {NUM_GAMES} games')
logger.info(f'Average score: {np.mean([r["score"] for r in results])}')
logger.info(f'Max score: {max([r["score"] for r in results])}')
logger.info(f'Min score: {min([r["score"] for r in results])}')
logger.info(f'32768 clear count: {sum([1 if r["maxtile"] >= 15 else 0 for r in results])}')
logger.info(f'16384 clear count: {sum([1 if r["maxtile"] >= 14 else 0 for r in results])}')
logger.info(f' 8192 clear count: {sum([1 if r["maxtile"] >= 13 else 0 for r in results])}')
logger.info(f' 4096 clear count: {sum([1 if r["maxtile"] >= 12 else 0 for r in results])}')
logger.info(f' 2048 clear count: {sum([1 if r["maxtile"] >= 11 else 0 for r in results])}')

