import cnn22B
import playalg
import tensorflow._api.v2.compat.v1 as tf
import Game2048 as Game
import numpy as np

sess = tf.InteractiveSession()
sess.run(tf.global_variables_initializer())
# saver = tf.train.Saver(max_to_keep=None)

model = cnn22B.Model()
print(model.DIM_I)

bd = Game.State()
bd.initGame()
print(bd.board)

# ev,dir = playalg.simplePlay(bd,sess,model)

x = np.zeros(model.DIM_I)

bd.board[15] = 18
print(bd.board)

model.make_input(x,bd.board)

print(x)


