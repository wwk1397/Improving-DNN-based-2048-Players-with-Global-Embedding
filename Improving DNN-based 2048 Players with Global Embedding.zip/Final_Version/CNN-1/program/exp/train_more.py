'''
   Experiment 6: Program
   Training with restart and jump start
'''
import tensorflow._api.v2.compat.v1 as tf
tf.disable_v2_behavior()
import numpy as np
import sys, os, random, logging
import queue, threading, concurrent.futures

sys.path.append('../common')
import Game2048

import os
os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

# usage: python training_restart_jump 1 cnn22B restart=[True|False] jump=[nojump|s-jump|l-jump]
seed = 1

numthread = 5
bsize = 1024
modelname = 'cnn22B'
restart = True
jump = 's-jump'

# Logging
logdir = f'{os.path.basename(__file__[:-3])}_{modelname}_{seed}'
if not os.path.exists(logdir): os.makedirs(logdir)
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
fh = logging.FileHandler(f'{logdir}/training.log')
fh.setLevel(logging.DEBUG)
fh.setFormatter(logging.Formatter('%(name)s:%(levelname)s:%(asctime)s:%(message)s'))
logger.addHandler(fh)

logger.info(f'Execution parameters: {sys.argv}')

# Preparing model and seed
exec(f'import {modelname} as modeler')
model = modeler.Model()
logger.info(f'NN model: {model.description}')
logger.info(f'NN number of parameters: {model.numparams}')

random.seed(seed)
np.random.seed(seed)
tf.set_random_seed(seed)
np.set_printoptions(threshold=np.inf)

# Preparing session
sess = tf.InteractiveSession()
sess.run(tf.global_variables_initializer())
saver = tf.train.Saver(max_to_keep=None)

queueA = queue.Queue(100000)
saver.restore(sess, f'./{logdir}/weights-300')


import playalg
def generator(threadID):
    ''' A function for generator thread '''
    def makeInitState(jump, threadID):
        if jump == 'nojump':
            state = Game2048.State()
            state.initGame()
            return state
        elif jump == 's-jump':
            cells = list(range(16)); random.shuffle(cells)
            tiles = [[1 if random.random() < 0.9 else 2, 1 if random.random() < 0.9 else 2],
                     [11, 1 if random.random() < 0.9 else 2],
                     [12, 1 if random.random() < 0.9 else 2],
                     [11, 12],
                     [13, 1 if random.random() < 0.9 else 2]]
            state = Game2048.State()
            state.board[cells[0]] = tiles[threadID][0]
            state.board[cells[1]] = tiles[threadID][1]
            return state
        elif jump == 'l-jump':
            cells = list(range(16)); random.shuffle(cells)
            tiles = [[1 if random.random() < 0.9 else 2, 1 if random.random() < 0.9 else 2],
                     [12, 1 if random.random() < 0.9 else 2],
                     [13, 1 if random.random() < 0.9 else 2],
                     [12, 13],
                     [14, 1 if random.random() < 0.9 else 2]]
            state = Game2048.State()
            state.board[cells[0]] = tiles[threadID][0]
            state.board[cells[1]] = tiles[threadID][1]
            return state
        else:
            raise ValueError(jump)

    def run():
        while True:
            state = makeInitState(jump, threadID)
            turn = 0
            states = []
            for restartcount in range(10000):
                lastboard = None
                while True:
                    turn += 1
                    dir,ev = playalg.simplePlay(state, sess, model)
                    state.play(dir)
                    if lastboard is not None: queueA.put( {'lastboard':lastboard, 'target':ev} )
                    lastboard = state.clone().board
                    state.putNewTile()
                    states.append(state.clone())
                    if state.isGameOver():
                        queueA.put( {'lastboard':lastboard, 'target':0.0} )
                        logger.info(f'game over thread {threadID} restart {restartcount} score {state.score} length {len(states)}')
                        break
                if restart and len(states) > 10:
                    # restart
                    state = states[len(states)//2]; turn -= len(states)//2; states = []
                else:
                    # go back to game start
                    break
    return run

def trainer():
    ''' A function for trainer thread '''
    OUTPUT_TIMING = 1000000
    learned_actions = 0
    while True:
        trainrecords = []
        while True:
            trainrecords.append(queueA.get())
            if len(trainrecords) == bsize: break

        x = np.zeros([len(trainrecords), model.DIM_I])
        y = np.zeros([len(trainrecords), model.DIM_O])
        for (i, playrecord) in enumerate(trainrecords):
            model.make_input(x[i,:], playrecord['lastboard'])
            y[i,:] = playrecord['target']
        l, _ = sess.run([model.loss, model.train_step], feed_dict={model.input:x, model.correct:y})
        learned_actions += len(trainrecords)

        logger.info(f'learned: {learned_actions:8,d} loss: {l:8,.2f}')

        # output parameters
        if ((learned_actions - len(trainrecords)) // OUTPUT_TIMING) < (learned_actions // OUTPUT_TIMING):
            saver.save(sess, f'./{logdir}/weights', global_step=(learned_actions//OUTPUT_TIMING))
            logger.info(f'saved parameters ./{logdir}/weights-{learned_actions//OUTPUT_TIMING}.*')

generator_executor = concurrent.futures.ThreadPoolExecutor(max_workers=numthread)
for  i in range(numthread): generator_executor.submit(generator(i))
# generator(0)()

trainer()
