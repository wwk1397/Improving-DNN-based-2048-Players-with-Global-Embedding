import cnn22B

mod = cnn22B.Model()

print(mod.numparams)
